#!/usr/bin/perl

#
# This program is part of the VA Cerberus Test Control System.
# Unless otherwise noted, Copyright (c) 2000 VA Linux Systems, 
# All Rights Reserved.
# You may distribute this program under the terms of the GNU General
# Public License, Version 2, or, at your option, any later version.
#

#
# va_detect.pm
# This is a simple detection library for use with Cerberus.
#

# run this at startup
sub va_detect_init {
	my $i;
	system("/sbin/rmmod ide-scsi >> /dev/null 2>&1");
	foreach $i ("ide-cd","ide-floppy","ide-tape") {
		system("/sbin/modprobe $i >> /dev/null 2>&1");
	}
}

sub get_preferred_cdrom {
	my @cdrw=get_cdrw_drives();
	my @cdroms=get_cdrom_drives();
	my $i;
	my $j;
	my $prefer;
	my @preferences;

	foreach $i (@cdroms) {
		$prefer=1;
		foreach $j (@cdrw) {
			if ($i eq $j) {
				$prefer=0;
			}
		}
		if ($prefer) {
			push @preferences, $i;
		}
	}
	foreach $j (@cdrw) {
		push @preferences, $j;
	}

	return @preferences;
}	

sub get_cdrom_drives {
	my @cdroms;
	my @cdroms_tmp;
	# find out any cdroms, don't burn them in!
	if ( -e "/proc/sys/dev/cdrom/info" ) {
		$_=`cat /proc/sys/dev/cdrom/info | grep "drive name" | cut -f 2 -d :`;
		@cdroms_tmp = split;
	}
	foreach $_ (@cdroms_tmp) {
		if (/sr(\d)/) {
			push @cdroms, "scd".$1;
		} else {
			push @cdroms, $_;
		}
	}
	return @cdroms;
}

sub get_cdrw_drives {
	my @cdrw;
	# find all SCSI
	my $count=0;
	open SCSI, "/proc/scsi/scsi";
	while (defined($l = <SCSI>)) {
		chomp $l;
		if ($l =~ /Type:\s+CD-ROM/ ) {
			++$count;
		} elsif ($l =~ /Model:\s+CD-Writer/i) {
			push (@cdrw, "scd".$count);
		} elsif ($l =~ /Model:\s+CD-RW/i) {
			push (@cdrw, "scd".$count);
		}
	}
	# TODO: IDE not supported
	return @cdrw;
}

sub ident_ide_floppy {
	my $ide_floppy=shift;
	$_=`cat /proc/ide/$ide_floppy/model`;
	foreach $i ("ZIP 250", "LS-120") {
		if (/$i/) {
			return $i;
		}
	}
}

sub get_ide_floppies {
	my $i;
	my @try_drives;
	$_=`ls -d /proc/ide/hd? 2>/dev/null | cut -f 4 -d / 2>/dev/null`;
	@try_drives=split;
	my @ide_floppies;
	foreach $i (@try_drives) {
		if ( $i =~ /hd/ ) {
			system ("cat /proc/ide/$i/driver | grep \"ide-floppy\" >> /dev/null 2>&1");
			if ( $? == 0 ) {
				push @ide_floppies, $i;
			}
		}
	}
	return @ide_floppies;
}

# gets Iomega devices attached to SCSI.
sub get_jaz_drives {
	my @jazzip;
	# Detect everything made by Iomega (TM)
	# Generally these shouldn't be burned in.
	if ( -e "/proc/scsi/scsi" ) {
		# JAZ detection from testproc 1.1.2
		my $count = 0;
		my $l;
		open SCSI, "/proc/scsi/scsi";
		while (defined($l = <SCSI>)) {
			chomp $l;
			if ($l =~ /Type:\s+Direct-Access/ ) {
				++$count;
			} elsif ($l =~ /Vendor:\s+iomega/i) {
				push (@jazzip, "sd".chr(ord("a")+$count));
			}
		}
	}
	return @jazzip;
}

# get all drives
sub get_drives {
	my @drives;
	my @line;
	my $i;
	
	open (PARTITIONS,"/proc/partitions");
	# skip two lines
	<PARTITIONS>;
	<PARTITIONS>;
	
	while (<PARTITIONS>) {
		@line = split;
		$_ = $line[3];
		if ( (! /\D*\d/) or /c\d*d\d*$/ ) {
			push @drives, $_;
		}
	}

	return @drives;
}

sub get_makej_parameter {
	my $processors;
	$processors=`cat /proc/cpuinfo  | grep processor | wc -l`;
	return $processors * 2;
}

sub get_linux_partitions {
	my @drives = @_;
	my @partitions;
	my $i;
	open (FDISK, "fdisk -l /dev/" . join (" /dev/",@drives) . " 2>/dev/null | grep \" 83 \" |");
	
	while (<FDISK>) {
		if ( /\/dev\/(\S*)\s*/ ) {
			push @partitions,$1;
		}
	}
	return @partitions;
}

sub get_swap {
	my $swapram = 0;
	open (SWAP, "/proc/meminfo");
	while (<SWAP>) {
		if ( /SwapTotal:\s*(\d*)\skB/ ) {
			$swapram += $1;
		}
	}
	return $swapram;
}

sub get_ram {
	my $kbram = 0;
	open (MEMORY, "/proc/meminfo");

	while (<MEMORY>) {
		if ( /MemTotal:\s*(\d*)\skB/ ) {
			$kbram += $1;
		}
# don't do that.  BigTotal is already part of MemTotal.
#		if ( /BigTotal:\s*(\d*)\skB/ ) {
#			$kbram += $1;
#		}
	}
	return $kbram;
}

#print get_ide_floppies;
#print "\n";
#print get_drives;
#print "\n";
#print get_cdrom_drives;
#print "\n";
#print get_jaz_drives;
#print "\n";
#foreach $i (get_ide_floppies) {
#	print "$i: ";
#	print ident_ide_floppy($i);
#	print "\n";
#}
va_detect_init;
1;
