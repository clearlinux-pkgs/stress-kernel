#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <malloc.h>
#include "memory.h"

/* this is horribly architecture specific */
#include <asm/page.h>

void kmemscan (int *buf, int i, int max, int align) {
	int kmem_file;
	unsigned long j=0;
	int c, low, high, foo,rd,a;
	unsigned long failure;

	low=i-10;
	high=i+10;
	if (low < 0) low=0;
	if (high > max) high=max;
	foo=low;
	fprintf(stderr, "Scanning /proc/kcore.  This is dangerous, take cover.\n");
/*	for(a=0;a<(sizeof(int));++a) { */
	a=0;  /* for some reason, only align 0 works.  Even when it shouldn't.  Strange. */
/*	fprintf(stderr, "align: %d\n", a);*/
	kmem_file = open("/proc/kcore",0);
	if (kmem_file < 0) {
		printf("Unable to open /proc/kcore.  No memory failure scanning possible.\n");
		return;
	}
	/* see above. (a=0) */
	read(kmem_file,&c,a);
	/* I would buffer this, but I might misdetect the failure location by scanning
	   the buffer rather than the actual memory area! */
	while( (rd=read(kmem_file, &c, sizeof(int))) != 0) {
		if(buf[foo] == c) {
			++foo;
		} else {
			foo = low;
		}
		if(foo==high) {
			/* convert to address */
			failure =  sizeof(int) * ((unsigned long) j - 10) + align;
			fprintf(stderr, "Possible location of memory failure: %p (%dM) on page %d\n",
				(void *) failure,
				(int) (failure/1024/1024),
				(int) (failure/PAGE_SIZE));
			foo = low;
			close(kmem_file);
			return;
		} 
		++j;
	}
	close(kmem_file);
	fprintf(stderr, "The memory failure location could not be determined. This happens sometimes.\n");
/* 	} */
}


void memtst(int verbose, int free_vm, int ceiling) {
  struct memory mem;
/*  int fd; */
  unsigned long nint;
  unsigned long tryint;
#define BS_SIZE 14
  int *buf, *nbuf, i, align, block, extra_vm, b, bs[BS_SIZE], l, ierror;
/*  int check[10];
    int k, j; */
/*  int consistent=0;
  int inconsistent=0;
  int nonerror=0; */
  /* Get size of main memory */
  meminfo(&mem);

  /*
   * Malloc a region the size of main memory, or as large as we can get.
   * If the system has enough swap space, this will let other programs
   * continue to run while we do this test.  Also, it appears to be
   * a large enough region to exercise most of main memory.
   * Leave at least free_vm MB of free virtual memory for other burn-in tests.
   * If the swap space is less than free_vm, then this means we decrease
   * the size of the buffer to leave more free memory.
   */
  extra_vm = (free_vm * 1024 * 1024 - mem.total_swap);
  if(extra_vm > 0) {
    nint = (unsigned) ((mem.total_mem - extra_vm)/sizeof(int));
  } else {
    nint = (unsigned) ((mem.total_mem - 4*1024*1024)/sizeof(int));
  }
  if(nint*sizeof(int) > ceiling*1024*1024) {
	nint=(ceiling*1024*1024)/sizeof(int);
  }

  tryint = nint;
  while((buf = (int *) calloc(sizeof(int),nint)) == NULL) {
    if(verbose) {
      printf("Unable to allocated requested memory.\n");
      printf("Decreasing request size by 5%%.\n");
    }
    nint = nint*0.95;
    /* we're deliberately making the tolerance here much smaller than it used to be */
    if(nint < .7*tryint) {
      fprintf(stderr, "Can't get enough memory to be worthwhile.  Giving up.\n");
      exit(2);
    }
  }
  printf("Ceiling: %dK\n", (ceiling*1024));
  printf("Attempting: %dK\n", (int) (nint * sizeof(int)/1024));
  printf("Testing: %ld integers, %ldK\n", nint, nint * (long) sizeof(int)/1024);
  /*
   * There are 2 things we vary as we walk across memory: the alignment
   * and the block size.
   * The alignment varies from 0 to 3.  We write 4 byte words on non-aligned byte
   * boundaries hoping to detect any errors caused by crossing non-aligned
   * boundaries.  The block size is the number of bytes that we write before
   * doing a verifying read.  It varies from 32K to the entire
   * buffer size.  This exercises cache more with the small block sizes and
   * main memory more with larger block sizes.
   */
  for(align = 0; align < sizeof(int) ; align++) {
    nbuf = (int *) (&(buf[align]));

    for(b=0 ; b < BS_SIZE ; ++b) {
	if (b < 5) {
		bs[b] = (b * 64 + 65) * 1024 / sizeof(int);
		if (bs[b] > nint) bs[b] = nint;
	} else {
		bs[b] = (nint/10) * (b-4);
		if (bs[b] > nint) bs[b] = nint;  /* just a safety check.  I don't want
                                                    anything stupid I do to break VA's factory */
	}
    }

/*    for(block = (256*1024/sizeof(int)); block < (nint - sizeof(int)); block += (nint/10)) { */
    for(b=0 ; b < BS_SIZE ; ++ b) {
      block=bs[b];
      /* Write to the buffer */
      if(verbose) printf("Writing block size %d (%dK) with alignment %d...", block, block*sizeof(int)/1024, align);
      fflush(stdout);
      for(i = 0; i < block; i++) {
	nbuf[i] = i + 0xaaaaaaaa;
      }
/* test failure */
/*      if (align == 0  && b == 5 ) {
	      nbuf[0xb7b] = 0x9a9f8da3;
      } */
      /* Verify the result */
      if(verbose) printf("Verifying...");
      fflush(stdout);
      for(i = 0; i < block; i++) {
	if(nbuf[i] != (i + 0xaaaaaaaa)) {
	  fprintf(stderr, "Memory error at offset %d of %d : expected %x, got %x\n", i, block, i + 0xaaaaaaaa, nbuf[i]);
	  fprintf(stderr, "Local process address: %p\n", &nbuf[i] );
	  kmemscan(nbuf, i, block, align);
	  ierror=i;
          if ( b < 5 ) {
		fprintf(stderr, "Cache RAM fault likely.  Check CPU first, then motherboard/System RAM.\n");
	  } else {
		fprintf(stderr, "System RAM fault likely.  Check System RAM first, then motherboard/CPU.\n");
	  }
	  fprintf(stderr, "Failure Context: \n");
	  fprintf(stderr, "offset\texpected\tgot\t\n");
	  for(l=ierror-3 ; l < block && l < ierror+7 ; ++l) {
		if (l == ierror) {
			fprintf(stderr, "%d\t%x\t%x  *** fail location\n",l,0xaaaaaaaa+l,nbuf[l]);
		} else {
			fprintf(stderr, "%d\t%x\t%x\n",l,0xaaaaaaaa+l,nbuf[l]);
		}
	  }
/* consistency checking is currently broken -- gcc is optimizing it away. */
/*	  fprintf(stderr, "Checking for consistency:\n");
	  for(j=0; j < 10 ; j++) { */
		/* I could use check[j] as the iterator but I want to make
		   sure assembly version of the loop is identical to the
		   above one */
/*	    check[j] = -1;
	    for(k=0; k < block; k++) {
	      if(nbuf[k] != (k + 0xaaaaaaaa)) {
	        fprintf(stderr, "Check %d error at offset %d of %d: expected %x, got %x\n",j,k,block,k+0xaaaaaaaa,nbuf[k]);
	  ierror=k;
	  fprintf(stderr, "Context: \n");
	  fprintf(stderr, "offset\texpected\tgot\t\n");
	  for(l=ierror-3 ; l < block && l < ierror+7 ; ++l) {
		if (l == ierror) {
			fprintf(stderr, "%d\t%x\t%x  *** fail location\n",l,0xaaaaaaaa+l,nbuf[l]);
		} else {
			fprintf(stderr, "%d\t%x\t%x\n",l,0xaaaaaaaa+l,nbuf[l]);
		}
	  }
  	        check[j] = k;
	        break;
	      }
            }
          } */
	  fflush(stdout);
	  fflush(stderr);
		/* clear out the memtest buffer */
	      for(i = 0; i < block; i++) {
		nbuf[i] = 0;
	      }

	  exit(1);
	}
      }
      if (verbose) printf("Done.\n");
      fflush(stdout);
    }
  }
  printf(" OK.\n");
  free(buf);
}
