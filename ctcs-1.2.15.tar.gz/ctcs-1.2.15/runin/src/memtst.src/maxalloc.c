/* maxalloc.c: print maximum number of megabytes we can allocate. */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <malloc.h>
#include "memory.h"

/* this is horribly architecture specific */
#include <asm/page.h>

void maxalloc(int ceiling) {
/*  unsigned int ceiling=4000;*/
  unsigned nint;
#define ATTEMPTS 30
  int *buf;
  int attempts=ATTEMPTS;
  unsigned nint_search;
  nint=(ceiling*(1024*1024 / sizeof(int)));
  nint_search = nint * 0.5;
  
/*  printf("%lu\n", (size_t) nint);*/

  /* while we've not reached maximum attempts and while the attempts
     aren't yet pointless */

  while((--attempts) > 0 && nint_search > (1000 / sizeof(int) / 2)) {
/*    printf("%d %u %u\n", ceiling, nint_search, nint); */
    if ((buf = (int *) malloc(nint*sizeof(int))) != NULL) {
	    free(buf);
	    if (attempts == ATTEMPTS - 1) {
		    break;
	    }
	    if (attempts > 1 && nint_search * .5 > (1000/sizeof(int)/2)) {
		    nint = nint + nint_search;
	    }
    } else {
	    if (nint_search > nint) {
      		    nint=0;
	    } else {
		    nint = nint - nint_search;
	    }
    }
    nint_search = nint_search * .5;
  }
  printf("%d\n", (int) (sizeof(int) * (nint / (1024*1024))));
/*  free(buf); */
}

int main(int argc, char **argv) {
        if (argc > 1) {
                maxalloc((int) strtol(argv[1],NULL,0));
	} else {
		maxalloc(4000);
        }
        return 0;
}
