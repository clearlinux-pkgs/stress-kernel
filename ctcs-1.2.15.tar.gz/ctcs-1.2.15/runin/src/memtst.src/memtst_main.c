/*
 * Memory Test Utility
 *
 * (c) Copyright VA Research, Inc. 1993-1999.  All rights reserved.
 *
 * You may redistribute this program under the terms of the General Public
 * License, version 2, or, at your option, any later version.
 *
 * Author: Larry M. Augustin
 *
 * 110199 (jtc):  Adjustable parameter for free VM.  Default is 128 MB.
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "memtst.h"
#include "memory.h"

int main(int argc, char **argv) {
	if (argc > 2) {
		memtst(1,(int) strtol(argv[1],NULL,0), (int) strtol(argv[2],NULL,0));
	} else if (argc > 1) {
		memtst(1,(int) strtol(argv[1],NULL,0),2048);
	} else {
		memtst(1,128,2048);
	}
	return 0;
}
