#ifndef MEMTST_H
#define MEMTST_H

void memtst(int verbose,int free_vm,int ceiling);

#endif
