#include <stdio.h>
#include "memory.h"

#define LINESIZE 1024

void meminfo( struct memory *m ) {
  FILE *f;
  char line1[LINESIZE], line2[LINESIZE], line3[LINESIZE];

  f = fopen("/proc/meminfo", "r");

  fgets(line1, LINESIZE-1, f);
  fgets(line2, LINESIZE-1, f);
  fgets(line3, LINESIZE-1, f);

  sscanf(line2, "%s %lu %lu %lu %lu %lu %lu", line1,
	 &(m->total_mem), 
	 &(m->used_mem), 
	 &(m->free_mem), 
	 &(m->shared_mem), 
	 &(m->buffer_mem), 
	 &(m->cached_mem));

  sscanf(line3, "%s %lu %lu %lu", line1,
	 &(m->total_swap), 
	 &(m->used_swap), 
	 &(m->free_swap));
}

