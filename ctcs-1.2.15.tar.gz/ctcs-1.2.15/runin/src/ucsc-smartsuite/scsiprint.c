/*
 * scsiprint.c
 *
 * Copyright (C) 2000 Michael Cornwell <cornwell@acm.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * (for example COPYING); if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include "smartctl.h"
#include "extern.h"
#include "scsicmds.h"


#define GBUF_SIZE 65535

UINT8 gBuf[GBUF_SIZE];

UINT8 gSmartPage = 0;
UINT8 gTempPage = 0;
UINT8 gSelfTestPage = 0;
UINT8 gStartStopPage = 0;





void scsiGetSupportPages ( int device)
{
	int i;
	if (logsense ( device , SUPPORT_LOG_PAGES, (UINT8 *) &gBuf) != 0)
	{
		perror ( "Log Sense failed"); 
				exit (1);
	
	} 

	for ( i = 4; i < gBuf[3] + LOGPAGEHDRSIZE ; i++)
	{
		switch ( gBuf[i])
		{
		case TEMPERATURE_PAGE:
			gTempPage = 1;
			break;
		case STARTSTOP_CYCLE_COUNTER_PAGE:
			gStartStopPage = 1;
			break;
		case SELFTEST_RESULTS_PAGE:
			gSelfTestPage = 1;
			break;
		case SMART_PAGE:
			gSmartPage = 1;
			break;
		default:
			break;
		}

	}

}

void scsiGetSmartData (int device)
{

	UINT8 returnvalue;
	UINT8 currenttemp;
	UINT8 triptemp;

	if ( scsiCheckSmart(device, gSmartPage, &returnvalue, &currenttemp, &triptemp ) != 0)
	{
		perror ( "scsiGetSmartData Failed");
		exit (1);
	}
	
	if ( returnvalue )
		printf("S.M.A.R.T. Sense: (%02x) %s\n", (UINT8) returnvalue, scsiSmartGetSenseCode(returnvalue));
	else
		printf("S.M.A.R.T. Sense: Okay!\n");
	
	if ( currenttemp || triptemp)
	{
		printf("Current Drive Temperature: %d C\n", currenttemp);
		printf("Drive Trip Temperature:	   %d C\n", triptemp);
	}
}


void scsiGetDriveInfo ( int device)
{
	char manufacturer[9];
	char product[17];
	char revision[5];

	UINT8 smartsupport;
	
	if (stdinquiry ( device, (UINT8 *) &gBuf) != 0)
	{
		perror ( "Standard Inquiry failed");
		exit (1);
	}

	memset ( &manufacturer, 0, 8);
	manufacturer[8] = '\0';
	strncpy ((char *) &manufacturer, (char *) &gBuf[8], 8);
	
	memset ( &product, 0, 16);
	strncpy ((char *) &product, (char *) &gBuf[16], 16);
	product[16] = '\0';
	
	memset ( &revision, 0, 4);
	strncpy ((char *) &revision, (char *) &gBuf[32], 4);
	revision[4] = '\0';
	printf("Device: %s %s Version: %s\n", manufacturer, product, revision);
	
	if ( scsiSmartSupport( device, (UINT8 *) &smartsupport) != 0)
	{
		printf(" Device does not Support S.M.A.R.T. \n");
		exit (1);
	}
	
	printf("Drive supports S.M.A.R.T. and is ");

	if (smartsupport & DEXCPT_ENABLE) 
		printf("Disabled\n");
	else
		printf("Enabled\n");

	if (smartsupport & EWASC_ENABLE)
		printf("Temperature Warning Enabled\n");
	else 
		printf("Temperature Warning Disabled or Not Supported\n");

}



void scsiSmartEnable( int device)
{
	
	/* Enable Exception Control */

	if ( scsiSmartDEXCPTDisable(device) != 0)
	{
		exit (1);
	}
	printf("S.M.A.R.T. enabled\n");
		

	if (scsiSmartEWASCEnable(device) != 0)
	{
		printf("Temperature Warning not Supported\n");
		
	}
	else
	{
		printf("Temperature Warning Enabled\n");
		
	}

	return;

}
	

void scsiSmartDisable (int device)
{

	if ( scsiSmartDEXCPTEnable(device) != 0)
	{
		exit (1);
	}
	printf("S.M.A.R.T. Disabled\n");
		

}


void scsiPrintMain (int fd)
{
	
	if (driveinfo)
		scsiGetDriveInfo(fd); 
	
	if (smartenable) 
		scsiSmartEnable(fd);


	if (smartdisable)
		scsiSmartDisable(fd);

	if (checksmart)
	{
		scsiGetSupportPages (fd);
		scsiGetSmartData(fd); 
	}	

}