
/*
 * scsicmds.c
 *
 * Copyright (C) 1999-2000 Michael Cornwell <cornwell@acm.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * You should have received a copy of the GNU General Public License
 * (for example COPYING); if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/hdreg.h>
#include <scsi/scsi.h>
#include "scsicmds.h"




UINT8 logsense (int device, UINT8 pagenum, UINT8 *pBuf)
{
  struct cdb10hdr *ioctlhdr;
  UINT8 tBuf[1024 + CDB_12_HDR_SIZE];
  UINT8 status;

  
  memset ( &tBuf, 0, 255);
    
  ioctlhdr = (struct cdb10hdr *) &tBuf;
  
  ioctlhdr->inbufsize = 0;
  ioctlhdr->outbufsize = 1024;
   
  ioctlhdr->cdb[0] = LOG_SENSE;
  ioctlhdr->cdb[1] = 0x00;
  ioctlhdr->cdb[2] = 0x40 | pagenum;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = 0x00;
  ioctlhdr->cdb[5] = 0x00;
  ioctlhdr->cdb[6] = 0x00;
  ioctlhdr->cdb[7] = 0x04;
  ioctlhdr->cdb[8] = 0x00;
  ioctlhdr->cdb[9] = 0x00;

  status =  ioctl( device, 1 , &tBuf);

	
  memcpy ( pBuf, &tBuf[8], 1024); 

  return status;
  
}




UINT8 modesense (int device,  UINT8 pagenum, UINT8 *pBuf)
{
  
  UINT8 tBuf[CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE ];
 
  struct cdb6hdr *ioctlhdr;
  	
  UINT8 status;

  memset ( &tBuf, 0, CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE );
  
  ioctlhdr = (struct cdb6hdr *) &tBuf;
  
  ioctlhdr->inbufsize = 0;
  ioctlhdr->outbufsize = 0xff;
   
  ioctlhdr->cdb[0] = MODE_SENSE;
  ioctlhdr->cdb[1] = 0x00;
  ioctlhdr->cdb[2] = pagenum;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = CDB_6_MAX_DATA_SIZE;
  ioctlhdr->cdb[5] = 0x00;
  
  
  status =  ioctl( device, 1 , &tBuf);
  
  memcpy ( pBuf, &tBuf[8], 256); 

  return status;

}




UINT8 modeselect (int device,  UINT8 pagenum, UINT8 *pBuf)
{
  struct cdb6hdr *ioctlhdr;
  UINT8 tBuf[CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE ];
  UINT8 status;

  memset ( &tBuf, 0, CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE );

  ioctlhdr = (struct cdb6hdr *) &tBuf;
  
  ioctlhdr->inbufsize = pBuf[0] + 1;
  ioctlhdr->outbufsize = 0;
  
  
  ioctlhdr->cdb[0] = MODE_SELECT;
  ioctlhdr->cdb[1] = 0x11;
  ioctlhdr->cdb[2] = 0x00;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = pBuf[0] + 1;
  ioctlhdr->cdb[5] = 0x00;
  
  tBuf[CDB_6_HDR_SIZE + 3]  = 0x08;
  tBuf[CDB_6_HDR_SIZE + 10] = 0x02;
  
    
  memcpy ( &tBuf[ CDB_6_HDR_SIZE + MODE_DATA_HDR_SIZE],
			 pBuf +  MODE_DATA_HDR_SIZE,
			pBuf[0] - MODE_DATA_HDR_SIZE + 1);

  tBuf[26] &= 0x3f;		
 
  status = ioctl( device, 1 , &tBuf);

  return status;

}




UINT8 modesense10 (int device, UINT8 pagenum, UINT8 *pBuf)
{
  
    struct cdb10hdr *ioctlhdr;
  UINT8 tBuf[1024];
  UINT8 status;
	
  memset ( &tBuf, 0, 1024);
    
  ioctlhdr = (struct cdb10hdr *) &tBuf;
  
  ioctlhdr->inbufsize = 0;
  ioctlhdr->outbufsize = 0xff;
   
  ioctlhdr->cdb[0] = MODE_SELECT_10;
  ioctlhdr->cdb[1] = 0x00;
  ioctlhdr->cdb[2] = 0x11;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = 0x00;
  ioctlhdr->cdb[5] = 0x00;
  ioctlhdr->cdb[6] = 0x00;
  ioctlhdr->cdb[7] = 0x00;
  ioctlhdr->cdb[8] = 0xff;
  ioctlhdr->cdb[9] = 0x00;

  status =  ioctl( device, 1 , &tBuf);
 
  memcpy ( pBuf, &tBuf[8], 0xff); 
  
  return status;

}




UINT8 modeselect10 (int device,  UINT8 pagenum, UINT8 *pBuf)
{
  struct cdb10hdr *ioctlhdr;
  UINT8 tBuf[CDB_10_MAX_DATA_SIZE + CDB_10_HDR_SIZE ];
  UINT8 status;

  memset ( &tBuf, 0, CDB_10_MAX_DATA_SIZE + CDB_10_HDR_SIZE );

  ioctlhdr = (struct cdb10hdr *) &tBuf;
  
  ioctlhdr->inbufsize = pBuf[0] + 1;
  ioctlhdr->outbufsize = 0;
  
  ioctlhdr->cdb[0] = MODE_SELECT_10;
  ioctlhdr->cdb[1] = 0x00;
  ioctlhdr->cdb[2] = pagenum;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = 0x00;
  ioctlhdr->cdb[5] = 0x00;
  ioctlhdr->cdb[6] = 0x00;
  ioctlhdr->cdb[7] = 0x00;
  ioctlhdr->cdb[8] = pBuf[0] + 1;
  ioctlhdr->cdb[9] = 0x00;
  
  tBuf[CDB_10_HDR_SIZE + 3]  = 0x08;
  tBuf[CDB_10_HDR_SIZE + 10] = 0x02;
  
    
  memcpy ( &tBuf[ CDB_10_HDR_SIZE + MODE_DATA_HDR_SIZE],
			 pBuf +  MODE_DATA_HDR_SIZE,
			pBuf[0] - MODE_DATA_HDR_SIZE + 1);

  tBuf[26] &= 0x3f;		
 
  status = ioctl( device, 1 , &tBuf);

  return status;

}




UINT8 stdinquiry ( int device, UINT8 *pBuf)
{
 
  UINT8 tBuf[CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE ];
 
  struct cdb6hdr *ioctlhdr;
  	
  UINT8 status;

  memset ( &tBuf, 0, CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE );
  
  ioctlhdr = (struct cdb6hdr *) &tBuf;
  
  ioctlhdr->inbufsize = 0;
  ioctlhdr->outbufsize = CDB_6_MAX_DATA_SIZE;
   
  ioctlhdr->cdb[0] = INQUIRY;
  ioctlhdr->cdb[1] = 0x00;
  ioctlhdr->cdb[2] = 0x00;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = CDB_6_MAX_DATA_SIZE;
  ioctlhdr->cdb[5] = 0x00;
  
  
  status =  ioctl( device, 1 , &tBuf);
  
  memcpy ( pBuf, &tBuf[8], 255); 

  return status;

}




UINT8 inquiry ( int device, UINT8 pagenum, UINT8 *pBuf)
{
 
  UINT8 tBuf[CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE ];
 
  struct cdb6hdr *ioctlhdr;
  	
  UINT8 status;

  memset ( &tBuf, 0, CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE );
  
  ioctlhdr = (struct cdb6hdr *) &tBuf;
  
  ioctlhdr->inbufsize = 0;
  ioctlhdr->outbufsize = 0xff;
   
  ioctlhdr->cdb[0] = INQUIRY;
  ioctlhdr->cdb[1] = 0x01;
  ioctlhdr->cdb[2] = 0x00;
  ioctlhdr->cdb[3] = pagenum;
  ioctlhdr->cdb[4] = CDB_6_MAX_DATA_SIZE;
  ioctlhdr->cdb[5] = 0x00;
  
  
  status =  ioctl( device, 1 , &tBuf);
  
  memcpy ( pBuf, &tBuf[8], 255); 

  return status;

}




UINT8 requestsense (int device, UINT8 *pBuf)
{
    
  UINT8 tBuf[CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE ];
 
  struct cdb6hdr *ioctlhdr;
  	
  UINT8 status;

  memset ( &tBuf, 0, CDB_6_MAX_DATA_SIZE + CDB_6_HDR_SIZE );
  
  ioctlhdr = (struct cdb6hdr *) &tBuf;
  
  ioctlhdr->inbufsize = 0;
  ioctlhdr->outbufsize = 0xff;
   
  ioctlhdr->cdb[0] = REQUEST_SENSE;
  ioctlhdr->cdb[1] = 0x00;
  ioctlhdr->cdb[2] = 0x00;
  ioctlhdr->cdb[3] = 0x00;
  ioctlhdr->cdb[4] = CDB_6_MAX_DATA_SIZE;
  ioctlhdr->cdb[5] = 0x00;
  
  
  status =  ioctl( device, 1 , &tBuf);
  
  memcpy ( pBuf, &tBuf[8], 255); 

  return status;
}




UINT8 testunitready (int device)
{
  return ioctl( device, 2 , NULL);

}




/* ModePage1C Handler */

#define SMART_SUPPORT	0x00	

UINT8 scsiSmartModePage1CHandler (int device, UINT8 setting, UINT8 *retval)
{
	char tBuf[CDB_6_MAX_DATA_SIZE];
	
	if (modesense ( device, 0x1c, (UINT8 *) &tBuf) != 0)
	{
		return 1;
	}
	
	switch (setting)
	{
		case DEXCPT_DISABLE:
			tBuf[14] &= 0x7f; /* turn off Perf bit */
 			tBuf[14] &= 0xf7;
			tBuf[15] = 0x04;
			break;
		case DEXCPT_ENABLE:
			tBuf[14] |= 0x80; /* turn on Perf value */
			tBuf[14] |= 0x08;
			break;
		case EWASC_ENABLE:
			tBuf[14] |= 0x10;
			break;
		case EWASC_DISABLE:
			tBuf[14] &= 0xef;
			break;
		case SMART_SUPPORT:
			*retval = tBuf[14] & 0x18;
			return 0;
			break;
		default:
			return 1;
	}
			
	if (modeselect ( device, 0x1c, (UINT8 *) &tBuf ) != 0)
	{
		return 1;
	}
	
	return 0;
}




UINT8 scsiSmartSupport (int device, UINT8 *retval)
{
	return scsiSmartModePage1CHandler( device, SMART_SUPPORT, retval);
}




UINT8 scsiSmartEWASCEnable (int device)
{
	return scsiSmartModePage1CHandler( device, EWASC_ENABLE, NULL);
}




UINT8 scsiSmartEWASCDisable (int device)
{
	return scsiSmartModePage1CHandler( device, EWASC_DISABLE, NULL);
}




UINT8 scsiSmartDEXCPTEnable (int device)
{
	return scsiSmartModePage1CHandler( device, DEXCPT_ENABLE, NULL);
}




UINT8 scsiSmartDEXCPTDisable (int device)
{
	return scsiSmartModePage1CHandler( device, DEXCPT_DISABLE, NULL);
}





UINT8 scsiCheckSmart(int device, UINT8 method, UINT8 *retval, UINT8 *currenttemp, UINT8 *triptemp)
{
	
	UINT8 tBuf[1024];
	UINT8 asc;
	UINT8 ascq;
	unsigned short pagesize;

	if ( method == CHECK_SMART_BY_LGPG_2F)
	{
	
		if (logsense ( device , SMART_PAGE, (UINT8 *) &tBuf) != 0)
		{
		perror ( "Log Sense failed");
		exit (1);
		}

		pagesize = (unsigned short) (tBuf[2] << 8) | tBuf[3];
		if ( !pagesize )
		{
		/* failed read of page 2F\n */
		return 1;
		}

		asc  = tBuf[8]; 
		ascq = tBuf[9];

		if ( pagesize == 8 && (currenttemp != NULL) && (triptemp != NULL) )
		{
		*currenttemp = tBuf[10];
		*triptemp =  tBuf[11];
		}	

	}
	else
	{
		if (requestsense ( device , (UINT8 *) &tBuf) != 0)
		{
		perror ( "Request Sense failed");
		exit (1);
		}
		asc = tBuf[12]; 
		ascq = tBuf[13];
		
	}

	if ( asc == 0x5d )
		*retval = ascq;
	else
		*retval = 0;
	return 0;
}



char* scsiSmartGetSenseCode ( UINT8 ascq)
{

 char *smartsensetable [] =   {
	"FAILURE PREDICTION THRESHOLD EXCEEDED",
	"MEDIA FAILURE PREDICTION THRESHOLD EXCEEDED",
	"LOGICAL UNIT FAILURE PREDICTION THRESHOLD EXCEEDED",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"HARDWARE IMPENDING FAILURE GENERAL HARD DRIVE FAILURE",
	"HARDWARE IMPENDING FAILURE DRIVE ERROR RATE TOO HIGH",
	"HARDWARE IMPENDING FAILURE DATA ERROR RATE TOO HIGH",
	"HARDWARE IMPENDING FAILURE SEEK ERROR RATE TOO HIGH",
	"HARDWARE IMPENDING FAILURE TOO MANY BLOCK REASSIGNS",
	"HARDWARE IMPENDING FAILURE ACCESS TIMES TOO HIGH",
	"HARDWARE IMPENDING FAILURE START UNIT TIMES TOO HIGH",
	"HARDWARE IMPENDING FAILURE CHANNEL PARAMETRICS",
	"HARDWARE IMPENDING FAILURE CONTROLLER DETECTED",
	"HARDWARE IMPENDING FAILURE THROUGHPUT PERFORMANCE",
	"HARDWARE IMPENDING FAILURE SEEK TIME PERFORMANCE",
	"HARDWARE IMPENDING FAILURE SPIN-UP RETRY COUNT",
	"HARDWARE IMPENDING FAILURE DRIVE CALIBRATION RETRY COUNT",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"CONTROLLER IMPENDING FAILURE GENERAL HARD DRIVE FAILURE",
	"CONTROLLER IMPENDING FAILURE DRIVE ERROR RATE TOO HIGH",
	"CONTROLLER IMPENDING FAILURE DATA ERROR RATE TOO HIGH",
	"CONTROLLER IMPENDING FAILURE SEEK ERROR RATE TOO HIGH",
	"CONTROLLER IMPENDING FAILURE TOO MANY BLOCK REASSIGNS",
	"CONTROLLER IMPENDING FAILURE ACCESS TIMES TOO HIGH",
	"CONTROLLER IMPENDING FAILURE START UNIT TIMES TOO HIGH",
	"CONTROLLER IMPENDING FAILURE CHANNEL PARAMETRICS",
	"CONTROLLER IMPENDING FAILURE CONTROLLER DETECTED",
	"CONTROLLER IMPENDING FAILURE THROUGHPUT PERFORMANCE",
	"CONTROLLER IMPENDING FAILURE SEEK TIME PERFORMANCE",
	"CONTROLLER IMPENDING FAILURE SPIN-UP RETRY COUNT",
	"CONTROLLER IMPENDING FAILURE DRIVE CALIBRATION RETRY COUNT",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"DATA CHANNEL IMPENDING FAILURE GENERAL HARD DRIVE FAILURE",
	"DATA CHANNEL IMPENDING FAILURE DRIVE ERROR RATE TOO HIGH",
	"DATA CHANNEL IMPENDING FAILURE DATA ERROR RATE TOO HIGH",
	"DATA CHANNEL IMPENDING FAILURE SEEK ERROR RATE TOO HIGH",
	"DATA CHANNEL IMPENDING FAILURE TOO MANY BLOCK REASSIGNS",
	"DATA CHANNEL IMPENDING FAILURE ACCESS TIMES TOO HIGH",
	"DATA CHANNEL IMPENDING FAILURE START UNIT TIMES TOO HIGH",
	"DATA CHANNEL IMPENDING FAILURE CHANNEL PARAMETRICS",
	"DATA CHANNEL IMPENDING FAILURE CONTROLLER DETECTED",
	"DATA CHANNEL IMPENDING FAILURE THROUGHPUT PERFORMANCE",
	"DATA CHANNEL IMPENDING FAILURE SEEK TIME PERFORMANCE",
	"DATA CHANNEL IMPENDING FAILURE SPIN-UP RETRY COUNT",
	"DATA CHANNEL IMPENDING FAILURE DRIVE CALIBRATION RETRY COUNT",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"SERVO IMPENDING FAILURE GENERAL HARD DRIVE FAILURE",
	"SERVO IMPENDING FAILURE DRIVE ERROR RATE TOO HIGH",
	"SERVO IMPENDING FAILURE DATA ERROR RATE TOO HIGH",
	"SERVO IMPENDING FAILURE SEEK ERROR RATE TOO HIGH",
	"SERVO IMPENDING FAILURE TOO MANY BLOCK REASSIGNS",
	"SERVO IMPENDING FAILURE ACCESS TIMES TOO HIGH",
	"SERVO IMPENDING FAILURE START UNIT TIMES TOO HIGH",
	"SERVO IMPENDING FAILURE CHANNEL PARAMETRICS",
	"SERVO IMPENDING FAILURE CONTROLLER DETECTED",
	"SERVO IMPENDING FAILURE THROUGHPUT PERFORMANCE",
	"SERVO IMPENDING FAILURE SEEK TIME PERFORMANCE",
	"SERVO IMPENDING FAILURE SPIN-UP RETRY COUNT",
	"SERVO IMPENDING FAILURE DRIVE CALIBRATION RETRY COUNT",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"SPINDLE IMPENDING FAILURE GENERAL HARD DRIVE FAILURE",
	"SPINDLE IMPENDING FAILURE DRIVE ERROR RATE TOO HIGH",
	"SPINDLE IMPENDING FAILURE DATA ERROR RATE TOO HIGH",
	"SPINDLE IMPENDING FAILURE SEEK ERROR RATE TOO HIGH",
	"SPINDLE IMPENDING FAILURE TOO MANY BLOCK REASSIGNS",
	"SPINDLE IMPENDING FAILURE ACCESS TIMES TOO HIGH",
	"SPINDLE IMPENDING FAILURE START UNIT TIMES TOO HIGH",
	"SPINDLE IMPENDING FAILURE CHANNEL PARAMETRICS",
	"SPINDLE IMPENDING FAILURE CONTROLLER DETECTED",
	"SPINDLE IMPENDING FAILURE THROUGHPUT PERFORMANCE",
	"SPINDLE IMPENDING FAILURE SEEK TIME PERFORMANCE",
	"SPINDLE IMPENDING FAILURE SPIN-UP RETRY COUNT",
	"SPINDLE IMPENDING FAILURE DRIVE CALIBRATION RETRY COUNT",
	"Unknown Failure",
	"Unknown Failure",
	"Unknown Failure",
	"FIRMWARE IMPENDING FAILURE GENERAL HARD DRIVE FAILURE",
	"FIRMWARE IMPENDING FAILURE DRIVE ERROR RATE TOO HIGH",
	"FIRMWARE IMPENDING FAILURE DATA ERROR RATE TOO HIGH",
	"FIRMWARE IMPENDING FAILURE SEEK ERROR RATE TOO HIGH",
	"FIRMWARE IMPENDING FAILURE TOO MANY BLOCK REASSIGNS",
	"FIRMWARE IMPENDING FAILURE ACCESS TIMES TOO HIGH",
	"FIRMWARE IMPENDING FAILURE START UNIT TIMES TOO HIGH",
	"FIRMWARE IMPENDING FAILURE CHANNEL PARAMETRICS",
	"FIRMWARE IMPENDING FAILURE CONTROLLER DETECTED",
	"FIRMWARE IMPENDING FAILURE THROUGHPUT PERFORMANCE",
	"FIRMWARE IMPENDING FAILURE SEEK TIME PERFORMANCE",
	"FIRMWARE IMPENDING FAILURE SPIN-UP RETRY COUNT",
	"FIRMWARE IMPENDING FAILURE DRIVE CALIBRATION RETRY COUNT"};

	if ( ascq == 0xff)
		return "SMART Sense: False Alarm";
	else if ( ascq <= SMART_SENSE_MAX_ENTRY)
		return smartsensetable[ascq];
	else
		return "Unknown Failure";

}
