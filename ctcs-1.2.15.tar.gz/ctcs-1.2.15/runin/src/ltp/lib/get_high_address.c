/* $Header: /cvsroot/va-ctcs/ctcs/runin/src/ltp/lib/get_high_address.c,v 1.2 2000/11/22 00:36:45 jtcollins Exp $ */

/*
 *	(C) COPYRIGHT CRAY RESEARCH, INC.
 *	UNPUBLISHED PROPRIETARY INFORMATION.
 *	ALL RIGHTS RESERVED.
 */

#include <unistd.h> 

char *
get_high_address()
{
       return (char *)sbrk(0) + 16384;
}
